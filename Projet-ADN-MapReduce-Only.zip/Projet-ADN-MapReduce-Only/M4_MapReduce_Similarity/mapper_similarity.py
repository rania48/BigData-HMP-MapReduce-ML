#!/usr/bin/env python3
"""
Mapper for similarity: blocking by emitting for top-N k-mers per sequence the tuple
Input: CSV accession_id,AAAAA,ACGTT,...
Output: kmer\taccession_id\tvector_json
This mapper picks top 10 kmers per sequence to create candidate blocks.
"""
import sys
import csv
import json

TOP_N = 10

r = csv.reader(sys.stdin)
header = next(r, None)
if not header:
    sys.exit(0)
feature_cols = header[1:]

for row in r:
    if not row:
        continue
    aid = row[0]
    vec = [float(x) for x in row[1:]]
    # pick top N indices
    pairs = list(zip(feature_cols, vec))
    pairs_sorted = sorted(pairs, key=lambda x: -x[1])[:TOP_N]
    vec_json = json.dumps(dict(pairs))
    for kmer, val in pairs_sorted:
        print(f"{kmer}\t{aid}\t{json.dumps(dict(pairs))}")
