#!/usr/bin/env python3
"""
Reducer for similarity: receives kmer\taccession_id\tvector_json grouped by kmer.
For each block, computes pairwise cosine similarity and emits pairs with similarity >= threshold.
Output: aid1\taid2\tsimilarity
"""
import sys
import json
import math
from itertools import combinations

THRESH=0.7

current_kmer=None
items=[]

for line in sys.stdin:
    line=line.strip()
    if not line:
        continue
    parts=line.split('\t',2)
    if len(parts)!=3:
        continue
    kmer,aid,vecj = parts
    if current_kmer is None:
        current_kmer=kmer
    if kmer!=current_kmer:
        # process block
        for a,b in combinations(items,2):
            aid1, vec1 = a
            aid2, vec2 = b
            # compute cosine over union of keys
            keys = set(vec1.keys()) | set(vec2.keys())
            v1 = [float(vec1.get(k,0.0)) for k in keys]
            v2 = [float(vec2.get(k,0.0)) for k in keys]
            dot = sum(x*y for x,y in zip(v1,v2))
            na = math.sqrt(sum(x*x for x in v1))
            nb = math.sqrt(sum(x*x for x in v2))
            if na==0 or nb==0: continue
            sim = dot/(na*nb)
            if sim>=THRESH:
                if aid1 < aid2:
                    print(f"{aid1}\t{aid2}\t{sim:.6f}")
                else:
                    print(f"{aid2}\t{aid1}\t{sim:.6f}")
        current_kmer = kmer
        items = []
    try:
        d = json.loads(vecj)
        # rebuild full vector as list of floats? We only have partial dict; convert to list of values
        # For similarity within block using only keys present, we'll use inner product over union of keys
        items.append((aid, d))
    except:
        continue

# final block
for a,b in combinations(items,2):
    aid1, vec1 = a
    aid2, vec2 = b
    # compute cosine on union of keys
    keys = set(vec1.keys()) | set(vec2.keys())
    v1 = [float(vec1.get(k,0.0)) for k in keys]
    v2 = [float(vec2.get(k,0.0)) for k in keys]
    dot = sum(x*y for x,y in zip(v1,v2))
    na = math.sqrt(sum(x*x for x in v1))
    nb = math.sqrt(sum(x*x for x in v2))
    if na==0 or nb==0: continue
    sim = dot/(na*nb)
    if sim>=THRESH:
        if aid1 < aid2:
            print(f"{aid1}\t{aid2}\t{sim:.6f}")
        else:
            print(f"{aid2}\t{aid1}\t{sim:.6f}")
