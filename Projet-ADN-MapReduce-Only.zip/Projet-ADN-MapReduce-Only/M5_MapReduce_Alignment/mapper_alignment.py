#!/usr/bin/env python3
"""
Mapper for alignment MapReduce: expects pairs aid1\taid2\tscore from similarity stage.
It reads a sequences JSONL provided via distributed cache (as a file on local filesystem) named 'sequences_kept.jsonl'
and emits aid1\taid2\talignment_score\taligned_len
"""
import sys
import json
import math

# load sequences file into memory
SEQ_FILE='sequences_kept.jsonl'
seq_map={}
try:
    with open(SEQ_FILE,'r',encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            r=json.loads(line)
            seq_map[r['accession_id']] = ''.join(r.get('fragments',[]))
except Exception as e:
    # if not present, mapper will skip
    pass

# simple Smith-Waterman (approximate, short)
def smith_waterman(a,b):
    n=len(a); m=len(b)
    if n==0 or m==0: return 0,0
    match=2; mismatch=-1; gap=-1
    H=[[0]*(m+1) for _ in range(n+1)]
    max_score=0
    for i in range(1,n+1):
        for j in range(1,m+1):
            score_diag = H[i-1][j-1] + (match if a[i-1]==b[j-1] else mismatch)
            score_up = H[i-1][j] + gap
            score_left = H[i][j-1] + gap
            H[i][j] = max(0, score_diag, score_up, score_left)
            if H[i][j] > max_score:
                max_score = H[i][j]
    aligned_len = int(max_score/2)
    return int(max_score), aligned_len

for line in sys.stdin:
    line=line.strip();
    if not line: continue
    parts=line.split('\t')
    if len(parts)<2: continue
    aid1, aid2 = parts[0], parts[1]
    sa = seq_map.get(aid1,'')
    sb = seq_map.get(aid2,'')
    if not sa or not sb:
        continue
    score, alen = smith_waterman(sa,sb)
    print(f"{aid1}\t{aid2}\t{score}\t{alen}")
