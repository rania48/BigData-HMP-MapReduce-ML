#!/usr/bin/env python3
"""
Reducer for alignment: identity reducer that can filter or aggregate alignments.
Input: aid1\taid2\tscore\taligned_len
Output: same
"""
import sys
for line in sys.stdin:
    line=line.strip()
    if not line: continue
    print(line)
