#!/usr/bin/env bash
set -euo pipefail

# Top-level runner for Projet-ADN-MapReduce-Only
ROOT="$(cd "$(dirname "$0")" && pwd)"
SCRIPTS="$ROOT/scripts"

echo "Starting Projet-ADN-MapReduce-Only pipeline"

# 1) Start hadoop (docker or local)
bash "$SCRIPTS/start_hadoop.sh"

# 2) Init HDFS
bash "$SCRIPTS/hdfs_init.sh"

# 3) Run full MapReduce flow
bash "$SCRIPTS/run_all_mapreduce.sh"

echo "Pipeline finished. Check $ROOT/output for exported results."
