#!/usr/bin/env python3
"""
Mapper: reads JSONL records (one per line) with fields 'accession_id' and 'fragments'
and emits k-mer occurrences as: accession_id\tkmer\t1
Designed for Hadoop Streaming.
"""
import sys
import json

K = 5

def kmers(seq, k=K):
    for i in range(len(seq)-k+1):
        kmer = seq[i:i+k]
        if all(c in 'ACGT' for c in kmer):
            yield kmer

for line in sys.stdin:
    line=line.strip()
    if not line:
        continue
    try:
        rec=json.loads(line)
        aid=rec.get('accession_id')
        frags=rec.get('fragments', [])
        if not aid or not frags:
            continue
        for frag in frags:
            for kmer in kmers(frag):
                print(f"{aid}\t{kmer}\t1")
    except Exception as e:
        continue
