#!/usr/bin/env python3
"""
Reducer: aggregates k-mer counts per accession_id.
Input: accession_id\tkmer\tcount
Output: accession_id\t{json_kmer_counts}
"""
import sys
import json
from collections import defaultdict

current_aid = None
counts = None

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts=line.split('\t')
    if len(parts) != 3:
        continue
    aid,kmer,c = parts
    try:
        c = int(c)
    except:
        continue
    if current_aid is None:
        current_aid = aid
        counts = defaultdict(int)
    if aid != current_aid:
        # emit previous
        print(current_aid + '\t' + json.dumps(counts, separators=(',',':')))
        current_aid = aid
        counts = defaultdict(int)
    counts[kmer] += c

if current_aid is not None:
    print(current_aid + '\t' + json.dumps(counts, separators=(',',':')))
