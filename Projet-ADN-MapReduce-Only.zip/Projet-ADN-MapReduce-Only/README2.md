Projet-ADN-MapReduce-Only
=========================

This folder contains a fully independent, MapReduce-only implementation of the ADN pipeline.
It is intentionally standalone and does not use Spark or any files from the original project.

Structure
---------
- M1_MapReduce_Preprocessing/parse_fasta.py  -> local FASTA -> sequences_kept.jsonl
- M2_MapReduce_Kmers/mapper_kmers.py, reducer_kmers.py
- M3_MapReduce_Vectors/mapper_vectors.py, reducer_vectors.py
- M4_MapReduce_Similarity/mapper_similarity.py, reducer_similarity.py
- M5_MapReduce_Alignment/mapper_alignment.py, reducer_alignment.py
- M6_MapReduce_KMeans/mapper_kmeans_assign.py, reducer_kmeans_update.py
- scripts/start_hadoop.sh, hdfs_init.sh, run_all_mapreduce.sh
- run_pipeline.sh  -> top-level driver

Quick start (assumes Hadoop + hadoop-streaming available or Docker)
-----------------------------------------------------------------
1) Make scripts executable

```bash
cd Projet-ADN-MapReduce-Only
chmod +x run_pipeline.sh scripts/*.sh M*/mapper_*.py M*/reducer_*.py
```

2) Provide raw FASTA files under `data_raw/` (create this directory and put your .fasta files there)

3) Run pipeline

```bash
./run_pipeline.sh
```

What the pipeline does
----------------------
1. Parses FASTA into `data_clean/sequences_kept.jsonl` (local)
2. Starts Hadoop (docker-compose if available or HADOOP_HOME)
3. Initializes HDFS directories `/projet-adn-mr` and uploads sequences
4. Runs a sequence of Hadoop Streaming jobs:
   - k-mer extraction (M2)
   - vector construction (M3)
   - similarity blocking & pairwise similarity (M4)
   - alignment for candidate pairs (M5)
   - K-Means iterative implemented in MapReduce (M6)
5. Exports final outputs to `output/` in the MR-only project directory

Notes & limitations
-------------------
- This implementation is pedagogical and aims to be runnable on small datasets for testing.
- The similarity MapReduce uses blocking by top-k k-mers. For very large datasets, additional partitioning is required.
- The K-Means MapReduce implementation is simple and may be slow; it is intended to demonstrate an iterative MR flow.
- The alignment step uses a Python Smith–Waterman implementation broadcast via distributed cache; for production use a compiled library is recommended.

If you want, I can:
- Add a `docker-compose.yml` (inside this MR-only folder) to spin up a test Hadoop cluster locally for validation.
- Run a small dry-run example by generating synthetic data and executing the pipeline (I will need permission to run Docker and Hadoop commands on your host).

