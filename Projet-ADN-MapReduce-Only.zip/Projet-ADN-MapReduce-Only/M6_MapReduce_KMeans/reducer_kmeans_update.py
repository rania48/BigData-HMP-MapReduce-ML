#!/usr/bin/env python3
"""
Reducer for KMeans: receives centroid_id\taccession_id\tvector_json and computes new centroid as mean.
Outputs new centroids as centroid_id,comma_separated_values
"""
import sys
import json
from collections import defaultdict

current_c = None
sums = None
count = 0

for line in sys.stdin:
    line=line.strip()
    if not line: continue
    parts=line.split('\t',2)
    if len(parts)!=3: continue
    cid, aid, vecj = parts
    try:
        vec = json.loads(vecj)
    except:
        vec = []
    if current_c is None:
        current_c = cid
        sums = None
        count = 0
    if cid != current_c:
        # emit centroid
        if sums is not None:
            mean = [s/count for s in sums]
            print(current_c+','+','.join(str(x) for x in mean))
        current_c = cid
        sums = None
        count = 0
    # vec is list
    if not isinstance(vec, list):
        continue
    if sums is None:
        sums = [0.0]*len(vec)
    for i,v in enumerate(vec):
        sums[i]+=float(v)
    count += 1

if current_c is not None and sums is not None and count>0:
    mean = [s/count for s in sums]
    print(current_c+','+','.join(str(x) for x in mean))
