#!/usr/bin/env python3
"""
KMeans MapReduce: mapper assigns each vector to nearest centroid.
Requires centroids file passed via distributed cache 'centroids.txt' lines: centroid_id,comma_separated_values
Input: CSV accession_id,vals...
Output: centroid_id\taccession_id,vals_json
"""
import sys
import csv
import json
import math

# load centroids
centroids = []
try:
    with open('centroids.txt','r') as f:
        for line in f:
            parts=line.strip().split(',',1)
            if len(parts)!=2: continue
            cid = parts[0]
            vals = [float(x) for x in parts[1].split(',') if x!='']
            centroids.append((cid, vals))
except:
    centroids=[]

r=csv.reader(sys.stdin)
header = next(r, None)
for row in r:
    aid = row[0]
    vec = [float(x) for x in row[1:]]
    best=None; bestd=None
    for cid, cvec in centroids:
        # compute euclidean
        d = math.sqrt(sum((a-b)**2 for a,b in zip(vec,cvec)))
        if bestd is None or d<bestd:
            bestd=d; best=cid
    # emit nearest centroid
    print(f"{best}\t{aid}\t{json.dumps(vec)}")
