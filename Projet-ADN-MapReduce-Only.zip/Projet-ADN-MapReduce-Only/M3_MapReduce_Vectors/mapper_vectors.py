#!/usr/bin/env python3
"""
Mapper for vectors stage: pass through accession_id and json counts
Input: accession_id\t{"AAAAA":2,...}
Output: same as input (mapper is identity) to allow Hadoop to group.
"""
import sys
for line in sys.stdin:
    line=line.strip()
    if not line:
        continue
    print(line)
