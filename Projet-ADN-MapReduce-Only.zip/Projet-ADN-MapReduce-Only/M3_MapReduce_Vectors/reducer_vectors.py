#!/usr/bin/env python3
"""
Reducer: build CSV vector with fixed k-mer order (all 4^K kmers where K=5)
Input: accession_id\t{json_counts}
Output: CSV header then rows accession_id,count,...
"""
import sys
import json
import itertools

K=5
ALL_KMERS = [''.join(p) for p in itertools.product('ACGT', repeat=K)]

first=True
for line in sys.stdin:
    line=line.strip()
    if not line:
        continue
    parts=line.split('\t',1)
    if len(parts)!=2:
        continue
    aid, j = parts
    try:
        d=json.loads(j)
    except:
        d={}
    if first:
        print('accession_id,'+','.join(ALL_KMERS))
        first=False
    values = [str(d.get(k,0)) for k in ALL_KMERS]
    print(aid+','+','.join(values))
