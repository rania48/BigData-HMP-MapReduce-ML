# Projet : Pipeline ADN MapReduce

Ce document décrit le rôle de chaque fichier et dossier du dépôt.

## Vue d'ensemble

Pipeline basé entièrement sur MapReduce pour le prétraitement de séquences ADN, l’extraction de k-mers, la vectorisation, le calcul de similarité, l’alignement, le clustering K-Means et la visualisation.

Le dépôt contient des scripts permettant une exécution locale ou distribuée via Hadoop (mode mono-nœud ou cluster Docker).

---

# Fichiers à la racine

- `docker-compose.single.yml`
  
  Configuration Docker Compose destinée à un environnement Hadoop mono-nœud. Permet de déployer rapidement un mini-cluster Hadoop local pour exécuter les jobs MapReduce (utilisé pour le test).

- `docker-compose.yml`
  
  Configuration Docker Compose complète pour un environnement plus avancé ou multi-services (cluster Hadoop plus complet, tests, etc.).

- `README2.md`
  
  Documentation principale du projet contenant la description générale, les instructions d’installation et les étapes d’exécution.

- `run_pipeline.sh`
  
  Script principal permettant d’exécuter automatiquement l’ensemble du pipeline MapReduce de bout en bout.

---

# Données et résultats

## `data_clean/`

Contient les données nettoyées prêtes à être utilisées par Hadoop.

### Fichiers

- `sequences_kept.jsonl`
  
  Fichier JSON Lines généré après le prétraitement des fichiers FASTA.
  
  Chaque ligne représente une séquence ADN sous forme d’objet JSON.

---

## `output_local/`

Contient les résultats exportés localement après l’exécution du pipeline.

### Fichiers

- `alignment.csv`
  
  Résultats d’alignement des séquences ADN.

- `similarity.csv`
  
  Résultats du calcul de similarité entre séquences.

- `vectors.csv`
  
  Représentations vectorielles générées à partir des k-mers.

---

# Étapes MapReduce (M1 à M7)

Chaque dossier correspond à une étape du pipeline.

Les scripts sont conçus pour être exécutés comme jobs Hadoop Streaming (Mapper / Reducer).

---

## M1_MapReduce_Preprocessing

### `parse_fasta.py`

Lit les fichiers FASTA bruts et produit un format structuré exploitable par Hadoop.

Fonctions principales :

- lecture des fichiers FASTA ;
- nettoyage des séquences ;
- filtrage des données invalides ;
- génération du fichier :

```text
data_clean/sequences_kept.jsonl
```

---

## M2_MapReduce_Kmers

### `mapper_kmers.py`

Mapper chargé de :

- lire les séquences ADN ;
- extraire les k-mers ;
- émettre les couples :

```text
(k-mer, occurrence)
```

### `reducer_kmers.py`

Reducer chargé de :

- agréger les occurrences des k-mers ;
- calculer les fréquences globales ou par séquence.

---

## M3_MapReduce_Vectors

### `mapper_vectors.py`

Transforme les fréquences de k-mers en composantes vectorielles.

### `reducer_vectors.py`

Assemble les composantes afin de construire :

```text
vectors.csv
```

Chaque séquence ADN est représentée par un vecteur de caractéristiques.

---

## M4_MapReduce_Similarity

### `mapper_similarity.py`

Prépare les comparaisons entre séquences.

Fonctions possibles :

- génération de paires candidates ;
- blocage (blocking) ;
- calculs partiels de similarité.

### `reducer_similarity.py`

Calcule les scores finaux de similarité.

Produit :

```text
similarity.csv
```

---

## M5_MapReduce_Alignment

### `mapper_alignment.py`

Prépare les paires de séquences à aligner.

Généralement :

- paires sélectionnées après le calcul de similarité.

### `reducer_alignment.py`

Effectue l’alignement ADN.

Peut implémenter :

- Smith-Waterman ;
- Needleman-Wunsch.

Produit :

```text
alignment.csv
```

---

## M6_MapReduce_KMeans

Implémentation distribuée de K-Means en MapReduce.

### `mapper_kmeans_assign.py`

Étape d’affectation :

- chaque vecteur est associé au centroïde le plus proche ;
- émission :

```text
(cluster_id, vecteur)
```

### `reducer_kmeans_update.py`

Étape de mise à jour :

- agrégation des vecteurs d’un cluster ;
- recalcul des centroïdes.

Cette étape est répétée jusqu’à convergence.

---

## M7_Visualisation

Module de visualisation des résultats.

### `export_visuals.sh`

Script chargé de :

- récupérer les résultats ;
- préparer les fichiers pour le tableau de bord.

### `index.html`

Page web affichant les visualisations interactives.

### `plot.js`

Code JavaScript chargé de :

- lire les données ;
- générer les graphiques interactifs.

---

## Dossier `data/`

Contient les fichiers utilisés par le tableau de bord.

### Fichiers

- `similarity.csv`
- `vectors.csv`

---

# Intégration avec M5_Visualisation

Le projet contient également :

```text
M5_Visualisation/visualisation.py
```

Ce script génère des visualisations statiques au format PNG :

- PCA 2D ;
- t-SNE ;
- distribution des clusters ;
- heatmap des k-mers ;
- métriques Random Forest ;
- matrice de confusion.

Les images sont enregistrées dans :

```text
M5_Visualisation/visualisations/
```

---

# Export automatique des visualisations

Le script :

```text
M7_Visualisation/export_visuals.sh
```

a été étendu afin de :

- détecter les PNG générés ;
- les copier automatiquement vers :

```text
M7_Visualisation/visualisations/
```

afin qu’ils soient affichés dans le tableau de bord.

---

# Visualisations supportées

Le tableau de bord affiche automatiquement :

- `1_distribution_clusters.png`
- `2_pca_2d.png`
- `3_tsne_2d.png`
- `4_heatmap_kmers.png`
- `5_rf_metrics.png`
- `6_confusion_matrix.png`

---

# Génération des visualisations

## 1. Générer les images

```bash
python3 M5_Visualisation/visualisation.py
```

## 2. Préparer les fichiers du dashboard

```bash
cd Projet-ADN-MapReduce-Only/M7_Visualisation
../export_visuals.sh
```

## 3. Lancer le serveur local

```bash
python3 -m http.server 8000
```

Puis ouvrir :

```text
http://localhost:8000
```

---

# Scripts utilitaires

## Dossier `scripts/`

### `dry_run_local.sh`

Exécution locale rapide du pipeline sans Hadoop.

### `hdfs_init.sh`

Création des répertoires HDFS et chargement des données.

### `run_all_mapreduce.sh`

Exécute toutes les étapes MapReduce dans l’ordre.

### `run_local_pipeline.sh`

Exécution locale complète du pipeline.

### `start_hadoop.sh`

Démarre les services Hadoop.

### `start_single_hadoop.sh`

Démarre un cluster Hadoop mono-nœud pour les tests.

---

# Flux d’exécution typique

```text
FASTA brut
      │
      ▼
M1 Prétraitement
      │
      ▼
sequences_kept.jsonl
      │
      ▼
M2 Extraction k-mers
      │
      ▼
M3 Vectorisation
      │
      ▼
vectors.csv
      │
      ▼
M4 Similarité
      │
      ▼
similarity.csv
      │
      ▼
M5 Alignement ADN
      │
      ▼
alignment.csv
      │
      ▼
M6 K-Means MapReduce
      │
      ▼
Clusters
      │
      ▼
M7 Visualisation
      │
      ▼
Dashboard HTML + Graphiques
```

---

# Paramètres et configuration

Les scripts MapReduce acceptent généralement :

- taille des k-mers ;
- seuil de similarité ;
- nombre de clusters K-Means ;
- chemins HDFS.

Consulter l’en-tête de chaque script Python pour connaître les paramètres disponibles.

---

# Configuration Docker

Les fichiers :

- `docker-compose.yml`
- `docker-compose.single.yml`

contiennent toute la configuration nécessaire au déploiement du cluster Hadoop dans Docker.

---

# Améliorations possibles

- Ajouter des exemples de commandes pour chaque étape.
- Documenter précisément tous les arguments des mappers et reducers.
- Ajouter des jeux de données d’exemple.
- Fournir un guide complet d’exécution locale et Docker.

---


