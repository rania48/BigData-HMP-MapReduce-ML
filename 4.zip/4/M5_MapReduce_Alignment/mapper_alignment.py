#!/usr/bin/env python3
"""
Mapper for alignment MapReduce.
Input:  aid1\taid2\tscore  (from similarity stage)
Output: aid1\taid2\talignment_score\taligned_len

Uses a fast approximate local alignment:
  - Encodes sequences as numpy uint8 arrays (O(n) once per sequence)
  - Slides a window of size W and counts matching positions (vectorized, no Python inner loop)
  - Score = best window match count; aligned_len = W
  This is O(n) per pair vs O(n^2) for full Smith-Waterman.
"""
import sys
import json
import numpy as np

SEQ_FILE = 'sequences_kept.jsonl'
MAX_LEN  = 300   # truncate sequences to limit memory
WINDOW   = 50    # sliding window size for local alignment approximation

seq_map = {}
try:
    with open(SEQ_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            r = json.loads(line)
            seq = ''.join(r.get('fragments', []))[:MAX_LEN]
            if seq:
                seq_map[r['accession_id']] = np.frombuffer(seq.encode(), dtype=np.uint8)
except Exception:
    pass

def fast_align(a, b):
    """Sliding-window approximate local alignment score. O(n) vectorized."""
    n, m = len(a), len(b)
    if n == 0 or m == 0:
        return 0, 0
    w = min(WINDOW, n, m)
    best = 0
    # slide window over the shorter sequence against the longer
    if n <= m:
        short, long_ = a, b
    else:
        short, long_ = b, a
    ns, nl = len(short), len(long_)
    w = min(WINDOW, ns)
    # try all starting positions in long_ that fit a window of size w
    for start in range(nl - w + 1):
        # compare short[:w] vs long_[start:start+w] — fully vectorized
        matches = int(np.sum(short[:w] == long_[start:start+w]))
        if matches > best:
            best = matches
    return best, w

for line in sys.stdin:
    line = line.strip()
    if not line: continue
    parts = line.split('\t')
    if len(parts) < 2: continue
    aid1, aid2 = parts[0], parts[1]
    if aid1 >= aid2:  # deduplicate pairs
        continue
    a = seq_map.get(aid1)
    b = seq_map.get(aid2)
    if a is None or b is None:
        continue
    score, alen = fast_align(a, b)
    print(f"{aid1}\t{aid2}\t{score}\t{alen}")
