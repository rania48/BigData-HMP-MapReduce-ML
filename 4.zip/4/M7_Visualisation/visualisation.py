import os, warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
warnings.filterwarnings('ignore')

BASE   = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT    = os.path.join(BASE, "output")
VISDIR = os.path.join(BASE, "M7_Visualisation", "visualisations")
os.makedirs(VISDIR, exist_ok=True)

COLORS = {"1": "#E74C3C", "2": "#2ECC71", "3": "#3498DB"}
LABELS = {"1": "Cluster 1", "2": "Cluster 2", "3": "Cluster 3"}

print("Loading data...")
vectors_df    = pd.read_csv(os.path.join(OUT, "vectors.csv"))
similarity_df = pd.read_csv(os.path.join(OUT, "similarity.csv"), sep="\t", header=None,
                             names=["seq1", "seq2", "score"])
alignment_df  = pd.read_csv(os.path.join(OUT, "alignment.csv"), sep="\t", header=None,
                             names=["seq1", "seq2", "sw_score", "aligned_len"])
assign_df     = pd.read_csv(os.path.join(OUT, "assignments.tsv"), sep="\t", header=None,
                             names=["cluster", "accession_id", "vector_json"])

assign_df = assign_df[["cluster", "accession_id"]].copy()
assign_df["cluster"] = assign_df["cluster"].astype(str)

full_df = vectors_df.merge(assign_df, on="accession_id")
feature_cols = [c for c in vectors_df.columns if c != "accession_id"]

print(f"  {len(full_df)} sequences, {len(feature_cols)} k-mer features, 3 clusters")

# ── VIZ 1: Cluster distribution ──────────────────────────────────────────────
print("[1/5] Cluster distribution...")
counts = assign_df["cluster"].value_counts().sort_index()
colors = [COLORS[c] for c in counts.index]

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.patch.set_facecolor("#F8F9FA")

ax = axes[0]
ax.set_facecolor("#F8F9FA")
bars = ax.bar(counts.index, counts.values, color=colors, edgecolor="white", width=0.5)
for bar, v in zip(bars, counts.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
            str(v), ha="center", fontsize=12, fontweight="bold")
ax.set_xlabel("Cluster", fontsize=12)
ax.set_ylabel("Sequences", fontsize=12)
ax.set_title("K-Means Cluster Distribution", fontsize=13, fontweight="bold")
ax.spines[["top","right"]].set_visible(False)

ax2 = axes[1]
ax2.pie(counts.values, labels=[LABELS[c] for c in counts.index], colors=colors,
        autopct="%1.1f%%", startangle=90, wedgeprops=dict(edgecolor="white", linewidth=2))
ax2.set_title("Proportional distribution", fontsize=13, fontweight="bold")

plt.suptitle(f"K-Means Clustering — {len(full_df)} DNA sequences", fontsize=14, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(VISDIR, "1_cluster_distribution.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 1_cluster_distribution.png")

# ── VIZ 2: PCA 2D ────────────────────────────────────────────────────────────
print("[2/5] PCA 2D...")
X = StandardScaler().fit_transform(full_df[feature_cols].values)
pca = PCA(n_components=2, random_state=42)
coords = pca.fit_transform(X)
var1, var2 = pca.explained_variance_ratio_ * 100

fig, ax = plt.subplots(figsize=(10, 7))
fig.patch.set_facecolor("#F8F9FA")
ax.set_facecolor("#1A1A2E")
for cid in ["1", "2", "3"]:
    mask = full_df["cluster"].values == cid
    ax.scatter(coords[mask, 0], coords[mask, 1], c=COLORS[cid], s=40,
               alpha=0.8, label=LABELS[cid], edgecolors="none")
ax.set_xlabel(f"PC1 ({var1:.1f}% var)", color="white")
ax.set_ylabel(f"PC2 ({var2:.1f}% var)", color="white")
ax.set_title(f"PCA 2D — DNA sequence k-mer vectors\n(explained variance: {var1+var2:.1f}%)",
             color="white", fontweight="bold")
ax.tick_params(colors="white")
ax.legend(fontsize=10, framealpha=0.2, facecolor="#2C3E50", labelcolor="white")
plt.tight_layout()
plt.savefig(os.path.join(VISDIR, "2_pca_2d.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 2_pca_2d.png")

# ── VIZ 3: K-mer heatmap ─────────────────────────────────────────────────────
print("[3/5] K-mer heatmap...")
means = full_df.groupby("cluster")[feature_cols].mean()
top = means.var(axis=0).nlargest(25).index.tolist()
hm = means[top].copy()
hm = (hm - hm.min()) / (hm.max() - hm.min() + 1e-8)

fig, ax = plt.subplots(figsize=(16, 4))
sns.heatmap(hm, ax=ax, cmap="YlOrRd", linewidths=0.3,
            cbar_kws={"label": "Normalised frequency"})
ax.set_title("Top 25 discriminant k-mers per cluster", fontsize=13, fontweight="bold")
ax.tick_params(axis="x", rotation=45, labelsize=8)
plt.tight_layout()
plt.savefig(os.path.join(VISDIR, "3_kmer_heatmap.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 3_kmer_heatmap.png")

# ── VIZ 4: Similarity score distribution ─────────────────────────────────────
print("[4/5] Similarity distribution...")
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
fig.patch.set_facecolor("#F8F9FA")

ax = axes[0]
ax.hist(similarity_df["score"], bins=30, color="#3498DB", edgecolor="white")
ax.set_xlabel("Cosine similarity score")
ax.set_ylabel("Pairs")
ax.set_title(f"Similarity distribution\n({len(similarity_df)} pairs, threshold ≥ 0.7)", fontweight="bold")
ax.spines[["top","right"]].set_visible(False)

ax2 = axes[1]
ax2.hist(alignment_df["sw_score"], bins=30, color="#E74C3C", edgecolor="white")
ax2.set_xlabel("Smith-Waterman score")
ax2.set_ylabel("Pairs")
ax2.set_title(f"Alignment score distribution\n({len(alignment_df)} aligned pairs)", fontweight="bold")
ax2.spines[["top","right"]].set_visible(False)

plt.tight_layout()
plt.savefig(os.path.join(VISDIR, "4_scores_distribution.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 4_scores_distribution.png")

# ── VIZ 5: Top aligned pairs ──────────────────────────────────────────────────
print("[5/5] Top aligned pairs...")
top_align = alignment_df.nlargest(20, "sw_score").copy()
top_align["pair"] = top_align["seq1"] + " ↔ " + top_align["seq2"]

fig, ax = plt.subplots(figsize=(12, 7))
colors_bar = ["#E74C3C" if s > top_align["sw_score"].median() else "#3498DB"
              for s in top_align["sw_score"]]
bars = ax.barh(top_align["pair"], top_align["sw_score"], color=colors_bar)
ax.set_xlabel("Smith-Waterman score")
ax.set_title("Top 20 sequence pairs by alignment score", fontsize=13, fontweight="bold")
ax.spines[["top","right"]].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(VISDIR, "5_top_alignments.png"), dpi=150, bbox_inches="tight")
plt.close()
print("  ✓ 5_top_alignments.png")

print(f"\nAll visualisations saved to: {VISDIR}")
